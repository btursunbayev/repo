#!/bin/bash

simple_switch_CLI << _EOF_
<delete this line and place control plane commands here for s1>
_EOF_
